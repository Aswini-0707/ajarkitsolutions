
document.addEventListener('DOMContentLoaded', () => {
    const counters = document.querySelectorAll('.counter');

    counters.forEach(counter => {
        counter.innerText = '0';
        
        const updateCounter = () => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText.replace('+', '');
            const increment = target / 200; // Increase the divisor to slow down the counter
            
            if (count < target) {
                counter.innerText = `${Math.ceil(count + increment)}+`;
                setTimeout(updateCounter, 20); // Increase the timeout duration to slow down the counter
            } else {
                counter.innerText = `${target}+`;
            }
        };
        
        updateCounter();
    });
});
